In order to run the project, compile the face.py file using Python 3.
- Make Sure Python 3 is installed in the system.
- Use either command prompt to run the file using the command - "python face.py" or open the Python IDE, browse for the file face.py and execute it in the IDE itself.